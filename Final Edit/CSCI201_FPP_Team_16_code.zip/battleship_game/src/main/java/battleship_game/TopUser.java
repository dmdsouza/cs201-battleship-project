package battleship_game;

public class TopUser {
	

	public String username;
	public String points;
	
	public TopUser(String name, String WonPoints) {
		this.username= name;
		this.points= WonPoints;
		
	}
	
	

}