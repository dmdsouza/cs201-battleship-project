package battleship_game;

import java.util.List;
import java.util.ArrayList;
public class Top10Users {
	
	public List<TopUser> users;
	
	public Top10Users(List<TopUser> list) {
		this.users=list;
		
	}
	
	

}